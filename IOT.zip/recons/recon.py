import os
from piwho import recognition
from piwho import vad
import RPi.GPIO as GPIO
import time

# Download the helper library from https://www.twilio.com/docs/python/install
from twilio.rest import Client


# Your Account Sid and Auth Token from twilio.com/console
account_sid = 'AC2ab524cc7675c0f32ecd201d3ee0016f'
auth_token = '93ed955b40f934942e88b5462a8ec89e'
client = Client(account_sid, auth_token)


def find_speaker():
    recog = recognition.SpeakerRecognizer('/home/pi/Downloads/recons/')

    # use newly recorded file.
    name = []
    name = recog.identify_speaker()
    dictn = recog.get_speaker_scores()
    found = float(dictn.get(name[0]))
    print(found)
    print(dictn)
    print(name)

    if (0.55 - found) < 0.0001:
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(26, GPIO.OUT)
        GPIO.output(26,GPIO.HIGH)
        print "unidentified"
        time.sleep(5)
        print "led off"
        GPIO.output(26, GPIO.LOW)
        message = client.messages \
    .create(
         body='There is an unknown person at your door!!',
         from_='+18885344064',
         to='+40724635280'
     )
    else:
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(19, GPIO.OUT)
        GPIO.output(19,GPIO.HIGH)
        print name[0]
        time.sleep(5)
        print "led off"
        GPIO.output(19, GPIO.LOW)
        message = client.messages \
    .create(
         body=name[0]+' just entered the house!!',
         from_='+18885344064',
         to='+40724635280'
     )
    return name

if __name__ == "__main__":
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    while True:
        input_state=GPIO.input(2)
        if input_state==0:
            print('Button pressed')
            time.sleep(0.2)
            break
    os.system("bash recon.sh")
    speaker = find_speaker()
    print(speaker[0])
