# Download the helper library from https://www.twilio.com/docs/python/install
from twilio.rest import Client


# Your Account Sid and Auth Token from twilio.com/console
account_sid = 'AC2ab524cc7675c0f32ecd201d3ee0016f'
auth_token = '93ed955b40f934942e88b5462a8ec89e'
client = Client(account_sid, auth_token)

message = client.messages \
    .create(
         body='This is the ship that made the Kessel Run in fourteen parsecs?',
         from_='+18885344064',
         to='+40724635280'
     )

print(message.sid)
