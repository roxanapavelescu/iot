#!/bin/bash

arecord -D plughw:1,0 -f S16_LE -r 16000 -d 5 test1.wav
sox -S test1.wav test_output1.wav rate -L -s 8000
omxplayer test_output1.wav
