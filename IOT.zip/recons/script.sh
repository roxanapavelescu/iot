#!/bin/bash


mkdir $1
cd $1
echo $1
for i in `seq 1 5`;
do
	arecord -D plughw:1,0 -f S16_LE -r 16000 -d 5 test$i.wav
	sox -S test$i.wav test_output$i.wav rate -L -s 8000
	omxplayer test_output$i.wav
done
rm test?.wav
rm test??.wav
cd ..