
=============
v1.3.2 - 2018-1-12
=============
-----
Fixed
-----
- Bug fixed: Model training doesn't work for more than 9 speakers.

-----
Added
-----
- Supports Python 3.6
- batch training example


=============
v1.3.1 - 2016-10-26
=============
-----
Fixed
-----
- Wrong PKG-INFO uploaded on pypi, nothing changed in source code.
- On Github the version is still 1.3.0


===================
v1.3.0 - 2016-10-26
===================
-------
Added
-------
- More examples

-------
Changed
-------
- MARF version to 0.3.0.6
- Replace SoX with audioop for wave resampling
- Now function ``identify_speaker()`` returns a list of two best speakers.
- Now JDK 1.7 & up is required
- Update docs
- Jasper module examples

-----
Fixed
-----
- Fix typos in recognition.rst
- Fix tests

====================
v1.1.0 - 2016-07-20
====================
-----
Added
-----
- Python 3.x support added

======================================
v1.0.0 -- 2016-06-20 (Initial release)
======================================
-----
Added
-----
- MARF verision 0.3.0.5
- Travis CI integration
- New tests
- Jasper Integration docs
- Support is limited to Python2.7
