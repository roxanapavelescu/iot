import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(19, GPIO.OUT)
GPIO.output(19,GPIO.HIGH)
print "conme on"
time.sleep(3)
print "led off"
GPIO.output(19, GPIO.LOW)

GPIO.setmode(GPIO.BCM)
GPIO.setup(26, GPIO.OUT)
GPIO.output(26,GPIO.HIGH)
print "conme on"
time.sleep(3)
print "led off"
GPIO.output(26, GPIO.LOW)


#while True:
#    input_state=GPIO.input(3)
#    if input_state==True:
#        print('Button pressed')
#        time.sleep(0.2)
